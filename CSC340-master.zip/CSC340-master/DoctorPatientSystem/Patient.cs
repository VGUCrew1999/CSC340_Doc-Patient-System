﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorPatientSystem
{
    class Patient
    {
        int pid;
        String name;
        String address;
        int age;
        String phone;
        String email;

        public int getId()
        {
            return pid;
        }

        public String getName()
        {
            return name;
        }

        public String getAdd()
        {
            return address;
        }
        public int getAge()
        {
            return age;
        }

        public String getPhone()
        {
            return phone;
        }

        public String getEmail()
        {
            return email;
        }


        public static ArrayList getPatientList()
        {
            ArrayList patientList = new ArrayList();  //a list to save the patient's data
            //prepare an SQL query to retrieve all the patients 
            DataTable myTable = new DataTable();
            string connStr = "server=csdatabase.eku.edu;user=stu_csc340;database=csc340_db;port=3306;password=Colonels18;";
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {
                Console.WriteLine("Connecting to MySQL...");
                conn.Open();
                string sql = "SELECT * FROM sans_patients ORDER BY p_id";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                //cmd.Parameters.AddWithValue("@myDate", dateString);
                MySqlDataAdapter myAdapter = new MySqlDataAdapter(cmd);
                myAdapter.Fill(myTable);
                Console.WriteLine("Table is ready.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();
            //convert the retrieved data to events and save them to the list
            foreach (DataRow row in myTable.Rows)
            {
                Patient newPatient = new Patient();
                newPatient.pid = Int32.Parse(row["p_ID"].ToString());
                newPatient.name = row["name"].ToString();
                newPatient.address = row["address"].ToString();
                newPatient.age = Int32.Parse(row["age"].ToString());
                newPatient.phone = row["phone"].ToString();
                newPatient.email = row["email"].ToString();
                patientList.Add(newPatient);
            }
            return patientList;  //return the event list
        }
    }
}
