﻿using MySql.Data.MySqlClient;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DoctorPatientSystem
{
    class Request
    {
        int requestId;
        int sId;
        int rId;
        string type;
        string status;
        string reqContent;

        public int getReqId()
        {
            return requestId;
        }

        public int getSend()
        {
            return sId;
        }

        public int getRequest()
        {
            return rId;
        }

        public String getType()
        {
            return type;
        }

        public String getStat()
        {
            return status;
        }

        public String getContent()
        {
            return reqContent;
        }

        public static ArrayList getRequestList(int id)
        {
            ArrayList requestList = new ArrayList();  //a list to save the patient's data
            //prepare an SQL query to retrieve all the patients 
            DataTable myTable = new DataTable();
            string connStr = "server=csdatabase.eku.edu;user=stu_csc340;database=csc340_db;port=3306;password=Colonels18;";
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {
                Console.WriteLine("Connecting to MySQL...");
                conn.Open();
                string sql = "SELECT * FROM sans_request3 WHERE recieveId=@id";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.Parameters.AddWithValue("@id", id);
                MySqlDataAdapter myAdapter = new MySqlDataAdapter(cmd);
                myAdapter.Fill(myTable);
                Console.WriteLine("Table is ready.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();
            //convert the retrieved data to events and save them to the list
            foreach (DataRow row in myTable.Rows)
            {
                Request newReq = new Request();
                newReq.requestId = Int32.Parse(row["reqId"].ToString());
                newReq.sId = Int32.Parse(row["sendId"].ToString());
                //newPatient.address = row["address"].ToString();
                newReq.rId = Int32.Parse(row["recieveId"].ToString());
                newReq.type = row["type"].ToString();
                newReq.reqContent = row["reqContent"].ToString();
                newReq.status = row["status"].ToString();
                requestList.Add(newReq);
            }
            return requestList;  //return the event list
        }
    }
}
