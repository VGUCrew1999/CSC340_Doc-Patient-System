drop database if exists Sans_Database;
create database if not exists Sans_Database;
use Sans_Database;

#pat = patient
#doc = doctor
#pha = pharmacist
drop table if exists PeopleId;
create table if not exists PeopleId(
	idNum int(3) not null auto_increment primary key,
	name varchar(50),
	p_type varchar(3)
);

drop table if exists Doctors;
create table if not exists Doctors(
	d_id int(3) primary key,
	name varchar(50),
	officeAdd varchar(70),
	phone varchar(10),
	email varchar(25),
	Foreign Key (d_id) References PeopleId (idNum)
);

drop table if exists Patients;
create table if not exists Patients(
	p_id int(3) primary key,
	name varchar(50),
	address varchar(70),
	age int(3),
	phone varchar(10),
	email varchar(25),
	Foreign Key (p_id) References PeopleId (idNum)
);

drop table if exists Pharmacists;
create table if not exists Pharmacists(
	ph_id int(3) primary key,
	name varchar(50),
	address varchar(70),
	phone varchar(10),
	email varchar(25),
	Foreign Key (ph_id) References PeopleId (idNum)
);

drop table if exists Pharmacy;
create table if not exists Pharmacy(
	ph_id int(3) primary key,
	name varchar(50),
	address varchar(70),
	phone varchar(10)
);

drop table if exists Appointment;
create table if not exists Appointment(
	confirmNum int(5) not null auto_increment primary key,
	docId int(3),
	patientId int(3),
	appDate date,
	appTime time,
	Foreign Key (patientId) References PeopleId(idNum),
	Foreign Key (docId) References PeopleId (idNum)
);

drop table if exists Message;
create table if not exists Message(
	idNum int(5) primary key,
	sendId int(3),
	recieveId int(3),
	content text,
	Foreign Key (sendId) References PeopleId(idNum),
	Foreign Key (recieveId) References PeopleId (idNum)
);

drop table if exists Prescription;
create table if not exists Prescription(
	idNum int(5) primary key,
	ownerId int(3),
	docId int(3),
	Foreign Key (ownerId) References PeopleId(idNum),
	Foreign Key (docId) References PeopleId (idNum)
);

# fil = refill
# med = medical records
# app = appointment
# pat = patient case discussion
drop table if exists Request;
create table if not exists Request(
	reqId int(5) primary key,
	sendId int(3),
	recieveId int(3),
	type varchar(3),
	reqContent text,
	Foreign Key (sendId) References PeopleId(idNum),
	Foreign Key (recieveId) References PeopleId (idNum)
);

drop table if exists Permission;
create table if not exists Permission(
	per_id int(3) primary key auto_increment,
	doc_id int(3),
	pat_id int(3),
	Foreign Key (doc_id) references Doctors (d_id),
	Foreign Key (pat_id) references Patients (p_id)
);

#comp = complete
#prog = in progress
#new = new
drop table if exists Refills;
create table if not exists Refills(
	rfill_id int(5) primary key,
	owner_id int(3),
	doc_id int(3),
	fill_status varchar(4),
	Foreign Key (owner_id) references Patients(p_id),
	Foreign Key (doc_id) references Doctors(d_id)
);

#insert statements

#1-3 are patients
#4 is a doctor
#5 is a pharmacist
insert into PeopleId (name, p_type) values
	('Alex Garbus', 'pat'),
	('Kenny Fugate', 'pat'),
	('Brandon Booth', 'pat'),
	('Mike Smith', 'doc'),
	('Jane Vires', 'pha');
	
insert into Patients (p_id, name, address, age, phone, email) values
	(1, 'Alex Garbus', '11 Main St Richmond, KY', 20, '1235454777', 'AGarbus@email'),
	(2, 'Kenny Fugate', '27 Main St Richmond, KY', 20, '1235454440', 'KFugate@email'),
	(3, 'Brandon Booth', '53 Main St Richmond, KY', 20, '1235463980', 'BBooth@email');
	
insert into Doctors (d_id, name, officeAdd, phone, email) values
	(4, 'Mike Smith', '36 42nd St Richmond, KY', '1547891453', 'MSmith@email');

insert into Pharmacists (ph_id, name, address, phone, email) values
	(5, 'Jane Vires', '57 Court St Richmond, KY', '1295476700', 'JVires@email');
	
insert into Permission (doc_id, pat_id) values
	(4, 1);

insert into Prescription (idNum, ownerId, docId) values
	(14, 1, 4),
	(57, 2, 4);
	
insert into Appointment (docId, patientId, appDate, appTime) values
	(4, 3, '2020-01-17', '10:00:00');
	
insert into Refills (rfill_id, owner_id, doc_id, fill_status) values
	(1, 1, 4, 'comp'),
	(2, 2, 4, 'prog'),
	(3, 3, 4, 'new');