USE csc340_db;

INSERT INTO sans_request3 (reqid, sendid, recieveid, TYPE, reqContent, status) VALUES
	(1, 1, 4, 'fil', 'I would like to have my prescription refilled.', 'new'),
	(2, 3, 4, 'app', 'I would like to have an appointment set up.', 'new'),
	(3, 4, 5, 'pat', 'I would like to dicsuss a case with you.', 'new');
	
INSERT INTO sans_request3 (sendid, recieveid, TYPE, reqContent, status) VALUES
	(4, 3, 'med', 'I would like to have access to your medical records.', 'new');